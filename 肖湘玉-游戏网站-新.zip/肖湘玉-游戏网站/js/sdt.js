/* ============================================================
 * sdt.js —— 信号检测论（SDT）数学工具与可视化模块
 *
 * 包含三部分：
 *   1. 统计函数：正态分布 PDF/CDF、反函数(Probit)、高斯随机抽样
 *   2. SDT 指标计算：P(Hit)、P(FA)、d′、c（含对极端比率的校正）
 *   3. Canvas 可视化：信号/噪音分布图、ROC 曲线
 * ============================================================ */

"use strict";

/* ---------------- 1. 统计函数 ---------------- */

/**
 * 标准正态分布概率密度函数 φ(x)
 */
function normalPdf(x, mu = 0, sigma = 1) {
  const z = (x - mu) / sigma;
  return Math.exp(-0.5 * z * z) / (sigma * Math.sqrt(2 * Math.PI));
}

/**
 * 误差函数 erf(x)（Abramowitz & Stegun 7.1.26 近似公式，精度 ~1e-7）
 * 用于计算正态分布 CDF
 */
function erf(x) {
  const sign = x >= 0 ? 1 : -1;
  x = Math.abs(x);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
  const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * x);
  const y = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-x * x);
  return sign * y;
}

/**
 * 标准正态分布累积函数 Φ(x)
 */
function normalCdf(x, mu = 0, sigma = 1) {
  return 0.5 * (1 + erf((x - mu) / (sigma * Math.SQRT2)));
}

/**
 * 将比率 p 钳制到开区间 (0,1)，避免 probit(0) / probit(1) 无穷大
 */
function clampP(p) {
  return Math.min(Math.max(p, 1e-6), 1 - 1e-6);
}

/**
 * 标准正态分布反函数（分位数函数）z = Φ⁻¹(p)
 * 采用 Peter Acklam 的有理逼近算法，精度约 1e-9。
 * SDT 中 d′ 与 c 的计算都需要它。
 */
function probit(p) {
  if (p <= 0 || p >= 1) throw new Error("probit(p) 要求 0 < p < 1");
  const a = [-3.969683028665376e+01, 2.209460984245205e+02,
             -2.759285104469687e+02, 1.383577518672690e+02,
             -3.066479806614716e+01, 2.506628277459239e+00];
  const b = [-5.447609879822406e+01, 1.615858368580409e+02,
             -1.556989798598866e+02, 6.680131188771972e+01,
             -1.328068155288572e+01];
  const c = [-7.784894002430293e-03, -3.223964580411365e-01,
             -2.400758277161838e+00, -2.549732539343734e+00,
              4.374664141464968e+00,  2.938163982698783e+00];
  const d = [7.784695709041462e-03, 3.224671290700398e-01,
             2.445134137142996e+00, 3.754408661907416e+00];
  const pLow = 0.02425, pHigh = 1 - pLow;

  let x, r;
  if (p < pLow) {
    // 左尾
    const q = Math.sqrt(-2 * Math.log(p));
    x = (((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
         ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1);
  } else if (p <= pHigh) {
    // 中央区域
    const q = p - 0.5, r = q * q;
    x = (((((a[0]*r + a[1])*r + a[2])*r + a[3])*r + a[4])*r + a[5])*q /
         (((((b[0]*r + b[1])*r + b[2])*r + b[3])*r + b[4])*r + 1);
  } else {
    // 右尾
    const q = Math.sqrt(-2 * Math.log(1 - p));
    x = -(((((c[0]*q + c[1])*q + c[2])*q + c[3])*q + c[4])*q + c[5]) /
          ((((d[0]*q + d[1])*q + d[2])*q + d[3])*q + 1);
  }
  // 牛顿法精修一步，提高精度
  const e = normalCdf(x) - p;
  const u = e * Math.sqrt(2 * Math.PI) * Math.exp(x * x / 2);
  x = x - u / (1 + x * u / 2);
  return x;
}

/**
 * 标准正态随机数（Box-Muller 变换）
 */
function gaussianRandom() {
  let u = 0, v = 0;
  while (u === 0) u = Math.random();   // 避免 log(0)
  while (v === 0) v = Math.random();
  return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
}

/* ---------------- 2. SDT 指标计算 ---------------- */

/**
 * 根据四格计数计算 SDT 指标。
 * 使用 log-linear 校正（Hautus, 1995）：对 0 计数加 0.5，
 * 避免比率取到 0 或 1 导致 z 值无穷大。
 *
 * @param {number} hit  击中数（信号 & 判"有信号"）
 * @param {number} miss 漏报数（信号 & 判"无信号"）
 * @param {number} fa   虚报数（噪音 & 判"有信号"）
 * @param {number} cr   正确拒绝数（噪音 & 判"无信号"）
 * @returns {{pHit, pFA, dprime, c, accuracy, beta}}
 */
function computeSDT(hit, miss, fa, cr) {
  const nSignal = hit + miss;   // 信号试验总数
  const nNoise = fa + cr;       // 噪音试验总数

  // log-linear 校正：比率 = (计数 + 0.5) / (总数 + 1)
  const pHit = (hit + 0.5) / (nSignal + 1);
  const pFA = (fa + 0.5) / (nNoise + 1);

  const zHit = probit(pHit);
  const zFA = probit(pFA);

  // 核心 SDT 公式：
  //   d′ = z(Hit) − z(FA)          —— 敏感性：把信号从噪音中分辨出来的能力
  //   c  = −0.5 × [z(Hit) + z(FA)] —— 判断标准：正=保守(倾向判"无")，负=宽松(倾向判"有")
  const dprime = zHit - zFA;
  const c = -0.5 * (zHit + zFA);
  // β = e^(c·d′)：似然比标准（另一种表达判断标准的方式）
  const beta = Math.exp(c * dprime);

  const accuracy = (hit + cr) / (nSignal + nNoise);
  return { pHit, pFA, dprime, c, accuracy, beta, zHit, zFA };
}

/* ---------------- 3. Canvas 可视化 ---------------- */

/**
 * 绘制信号/噪音分布图（加分项：分布随 d′ 变化的可视化）
 *
 * @param {HTMLCanvasElement} canvas
 * @param {number} dprime   敏感性（两分布均值的间距）
 * @param {number|null} criterion 判断标准位置（证据轴上的分界线 = −c；null 则不画）
 * @param {object} opts 可选覆盖：{ shade: 是否着色反应区 }
 */
function drawDistributions(canvas, dprime, criterion = null, opts = {}) {
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  const padL = 44, padR = 16, padT = 24, padB = 40;
  const plotW = W - padL - padR, plotH = H - padT - padB;

  // 证据轴范围：噪音 N(0,1) 与信号 N(d′,1)，两侧各留 3σ
  const xMin = -3.4, xMax = dprime + 3.4;
  const xToPx = x => padL + (x - xMin) / (xMax - xMin) * plotW;

  // 峰值高度（按当前 d′ 下 pdf 最大值归一化）
  const peak = Math.max(normalPdf(0), normalPdf(dprime));

  ctx.clearRect(0, 0, W, H);
  ctx.font = "12px 'Microsoft YaHei', sans-serif";

  // 坐标轴
  ctx.strokeStyle = "#c8cede";
  ctx.lineWidth = 1;
  ctx.beginPath();
  ctx.moveTo(padL, padT + plotH);
  ctx.lineTo(padL + plotW, padT + plotH);
  ctx.moveTo(padL, padT);
  ctx.lineTo(padL, padT + plotH);
  ctx.stroke();

  // 噪音分布（蓝色，均值 0）
  ctx.beginPath();
  ctx.moveTo(xToPx(xMin), padT + plotH);
  for (let px = 0; px <= plotW; px++) {
    const x = xMin + px / plotW * (xMax - xMin);
    const y = normalPdf(x, 0, 1) / peak;
    ctx.lineTo(xToPx(x), padT + plotH - y * plotH * 0.92);
  }
  ctx.lineTo(xToPx(xMax), padT + plotH);
  ctx.closePath();
  ctx.fillStyle = "rgba(43, 95, 217, 0.16)";
  ctx.fill();
  ctx.strokeStyle = "#2b5fd9";
  ctx.lineWidth = 2;
  ctx.stroke();

  // 信号分布（红色，均值 d′）
  ctx.beginPath();
  ctx.moveTo(xToPx(xMin), padT + plotH);
  for (let px = 0; px <= plotW; px++) {
    const x = xMin + px / plotW * (xMax - xMin);
    const y = normalPdf(x, dprime, 1) / peak;
    ctx.lineTo(xToPx(x), padT + plotH - y * plotH * 0.92);
  }
  ctx.lineTo(xToPx(xMax), padT + plotH);
  ctx.closePath();
  ctx.fillStyle = "rgba(217, 58, 73, 0.14)";
  ctx.fill();
  ctx.strokeStyle = "#d93a49";
  ctx.lineWidth = 2;
  ctx.stroke();

  // 判断标准虚线（位置 = −c）
  if (criterion !== null && criterion > xMin && criterion < xMax) {
    ctx.save();
    ctx.setLineDash([6, 5]);
    ctx.strokeStyle = "#7a4bd6";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(xToPx(criterion), padT - 6);
    ctx.lineTo(xToPx(criterion), padT + plotH);
    ctx.stroke();
    ctx.restore();
    ctx.fillStyle = "#7a4bd6";
    ctx.textAlign = "center";
    ctx.fillText("你的判断标准", xToPx(criterion), padT - 8);
  }

  // 均值标注
  ctx.textAlign = "center";
  ctx.fillStyle = "#2b5fd9";
  ctx.fillText("噪音 N (0,1)", xToPx(0), padT + plotH - normalPdf(0)/peak * plotH * 0.92 - 10);
  ctx.fillStyle = "#d93a49";
  ctx.fillText("信号 S (d′=" + dprime.toFixed(1) + ")",
               xToPx(dprime), padT + plotH - normalPdf(dprime)/peak * plotH * 0.92 - 10);

  // 轴标签
  ctx.fillStyle = "#6b7280";
  ctx.textAlign = "left";
  ctx.fillText("可疑程度（内部证据）→", padL + plotW - 130, padT + plotH + 26);
  ctx.textAlign = "right";
  ctx.fillText("密度", padL - 8, padT + 10);
}

/**
 * 绘制 ROC 曲线（加分项）
 * 理论 ROC：给定 d′，P(Hit) = Φ( Φ⁻¹(P(FA)) + d′ )
 * 并把被试本次的实际 (P(FA), P(Hit)) 画为红点。
 *
 * @param {HTMLCanvasElement} canvas
 * @param {{pHit:number, pFA:number}} observed 实际观测的比率
 */
function drawROC(canvas, observed) {
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  const pad = 42;
  const plotW = W - pad - 16, plotH = H - pad - 16;
  const xToPx = x => pad + x * plotW;
  const yToPx = y => pad + plotH - y * plotH;

  ctx.clearRect(0, 0, W, H);
  ctx.font = "12px 'Microsoft YaHei', sans-serif";

  // 背景网格
  ctx.strokeStyle = "#eef1f7";
  ctx.lineWidth = 1;
  for (let g = 0.1; g < 1; g += 0.1) {
    ctx.beginPath(); ctx.moveTo(xToPx(g), yToPx(0)); ctx.lineTo(xToPx(g), yToPx(1)); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(xToPx(0), yToPx(g)); ctx.lineTo(xToPx(1), yToPx(g)); ctx.stroke();
  }

  // 坐标轴
  ctx.strokeStyle = "#9aa3b5";
  ctx.lineWidth = 1.5;
  ctx.beginPath();
  ctx.moveTo(xToPx(0), yToPx(0));
  ctx.lineTo(xToPx(1), yToPx(0));
  ctx.moveTo(xToPx(0), yToPx(0));
  ctx.lineTo(xToPx(0), yToPx(1));
  ctx.stroke();

  // 对角线（d′ = 0，纯猜测水平）
  ctx.save();
  ctx.setLineDash([4, 4]);
  ctx.strokeStyle = "#c0c6d4";
  ctx.beginPath();
  ctx.moveTo(xToPx(0), yToPx(0));
  ctx.lineTo(xToPx(1), yToPx(1));
  ctx.stroke();
  ctx.restore();

  // 理论 ROC 曲线族
  const dps = [0.5, 1, 1.5, 2, 3];
  const colors = ["#dbe4f8", "#b9c9f0", "#8fabe8", "#5f83d8", "#2b5fd9"];
  dps.forEach((dp, i) => {
    ctx.beginPath();
    for (let px = 0; px <= 100; px++) {
      const pfa = px / 100;
      // 公式：Hit = Φ( Φ⁻¹(FA) + d′ )，钳制比率避免端点越界
      const phit = normalCdf(probit(clampP(pfa)) + dp);
      if (px === 0) ctx.moveTo(xToPx(pfa), yToPx(phit));
      else ctx.lineTo(xToPx(pfa), yToPx(phit));
    }
    ctx.strokeStyle = colors[i];
    ctx.lineWidth = 2;
    ctx.stroke();
    // 曲线末端标注 d′ 值
    const pfa = 0.62;
    const phit = normalCdf(probit(pfa) + dp);
    ctx.fillStyle = colors[i];
    ctx.textAlign = "left";
    ctx.fillText("d′=" + dp, xToPx(pfa) + 4, yToPx(phit));
  });

  // 被试实际观测点
  if (observed) {
    ctx.beginPath();
    ctx.arc(xToPx(observed.pFA), yToPx(observed.pHit), 7, 0, Math.PI * 2);
    ctx.fillStyle = "#d93a49";
    ctx.fill();
    ctx.strokeStyle = "#fff";
    ctx.lineWidth = 2;
    ctx.stroke();

    // 标注文字（自动避免出界）
    ctx.fillStyle = "#b72b39";
    ctx.font = "bold 12px 'Microsoft YaHei', sans-serif";
    const lx = observed.pFA > 0.7 ? xToPx(observed.pFA) - 70 : xToPx(observed.pFA) + 12;
    const ly = observed.pHit > 0.85 ? yToPx(observed.pHit) + 18 : yToPx(observed.pHit) - 10;
    ctx.fillText("你在这 ✓", lx, ly);
    ctx.font = "12px 'Microsoft YaHei', sans-serif";
  }

  // 轴标签
  ctx.fillStyle = "#6b7280";
  ctx.textAlign = "center";
  ctx.fillText("虚报率 P(FA)", pad + plotW / 2, H - 10);
  ctx.save();
  ctx.translate(14, pad + plotH / 2);
  ctx.rotate(-Math.PI / 2);
  ctx.fillText("命中率 P(Hit)", 0, 0);
  ctx.restore();
}
