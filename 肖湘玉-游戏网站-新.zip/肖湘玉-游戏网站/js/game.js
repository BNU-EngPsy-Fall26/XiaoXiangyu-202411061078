/* ============================================================
 * game.js —— 反诈审核员游戏主逻辑
 *
 * 实验流程：
 *   屏幕1（说明/参数设置）→ 屏幕2（逐次判断，20条/局，每条限时8秒）→ 屏幕3（SDT 结果）
 *
 * 刺激生成模型（游戏化的 SDT 生成过程）：
 *   每次试验先按先验概率 P(S) 决定本条消息真实身份（信号=诈骗 / 噪音=正常）；
 *   再为其抽样一个"可疑程度"内部证据 x：
 *     噪音：x ~ N(0, 1)   信号：x ~ N(d′, 1)
 *   依据 x 所在区间挑选对应"可疑等级"的消息文案（高/中/低可疑）。
 *   这样消息内容看起来自然，同时整局数据仍符合 SDT 的正态叠加模型。
 *
 * 计分：超时未答按"判为正常消息"计（保守反应）。
 * ============================================================ */

"use strict";

/* ---------------- 常量与配置 ---------------- */

const TRIALS_PER_BLOCK = 20;   // 每局试验次数（作业要求 ≥20）
const TIME_LIMIT_MS = 8000;    // 每条消息的判断限时
const FEEDBACK_MS = 750;       // 对错反馈的显示时长

/**
 * 消息素材库。
 * fraud  = 信号 S（真诈骗），noise = 噪音 N（真正常）
 * 每类按"可疑程度"分三档：high / medium / low，
 * 分别对应内部证据抽样值 x 的三个区间。
 *
 * 每条文案带 tag（主题标签），用于"主题去重"——
 * 即使内容不重复，相似主题也不在短期内连续刷屏。
 */
const MESSAGE_POOL = {
  fraud: {
    // 很明显的骗局（x > +0.5 时出现）
    high: [
      { tag: "police",          sender: "陌生号码 · 短信",      text: "【XX市公安局】王警官：你名下银行卡涉嫌一起洗钱案，需将资金转入“安全账户”配合清查。今晚6点前不配合将实施逮捕。" },
      { tag: "lottery",         sender: "系统通知 · 短信",      text: "恭喜您被抽为幸运用户，获得现金奖励88888元！仅需先缴纳2000元手续费即可领取，点击 t.cn/jiangli 立即到账。" },
      { tag: "brushing",        sender: "兼职群 · QQ消息",      text: "招聘线上刷单员，日结300-800元！动动手指就能赚钱。首单需自行垫付商品费，完成订单后本金+佣金秒返。" },
      { tag: "kidnap",          sender: "陌生号码 · 短信",      text: "您的子女在我手中，不想事情闹大就按提示转账。不许报警，不许告诉家人，我们会把钱原样退还……只是先做个测试。" },
      { tag: "surrogacy",       sender: "陌生号码 · 短信",      text: "本人30岁富商，因妻无法生育，诚征健康女士代孕，酬谢80万。需先付5000元诚意保证金签订协议，事成再付清。" },
      { tag: "sextortion",      sender: "陌生号码 · 微信",      text: "你昨晚视频里做的事我都录下来了，通讯录里你家人朋友电话我也有。不打款3000元我马上群发出去。" },
      { tag: "loan-fraud",      sender: "【XX借款】· 短信",     text: "您的50000元贷款额度已审批通过，额度有效至周五。放款前需缴纳1500元“工本费+保险费”，缴后10分钟到账。" },
      { tag: "student-loan",    sender: "金融客服 · 电话转短信", text: "【学生资助中心】您在校期间注册的校园贷账户未注销，影响个人征信。请加QQ:8830xx配合注销，需先验资5000元。" },
      { tag: "charity-bonus",   sender: "【国家补助】· 短信",    text: "您符合国家困难家庭补助条件，本月可领取补贴6800元。请点击 lianlibutie.com 填写银行卡信息领取，限今日。" },
      { tag: "account-safe",    sender: "官方客服 · 短信",     text: "【安全中心】您的账户存在被盗风险，需立即把余额转至安全验证账户核验。逾期将冻结账户并负法律责任。" },
      { tag: "tuition-deposit", sender: "海外招生办 · 邮件短信", text: "您的孩子已获XX大学录取并获半奖，需先汇款3万元保证金冻结至校方账户办理签证，到校注册后无息退还。" },
      { tag: "porn-membership", sender: "陌生号码 · QQ",        text: "加我微信看私密视频，月卡会员88元。注册需先交200元会员认证保证金，开通后系统自动退还。" },
      { tag: "exchange-travel",  sender: "旅游群 · 微信",        text: "我手上有港币，现汇比银行优惠20%。先转我20000元人民币，3小时内把港币寄到您香港酒店前台。" },
      { tag: "tax-penalty",     sender: "【税务局】· 短信",     text: "您名下企业漏报增值税合计36,000元，需立即补缴+滞纳金至国库指定账户ev-3210xx，否则依法采取强制措施。" },
      { tag: "house-deposit",   sender: "中介小李 · 微信",      text: "您看中那套房房东急售已可议价，先转我5000元意向金锁定，3天内不签合同全额退还，房子我给您留3天。" }
    ],
    // 中等可疑的骗局（-0.5 < x ≤ +0.5）
    medium: [
      { tag: "refund",            sender: "官方客服 · 电话转短信", text: "您好，您购买的面霜检测出质量问题，商家愿双倍赔付。请添加理赔专员QQ：8801xxxx，按指引操作即可领取200元赔付金。" },
      { tag: "etc",              sender: "【ETC服务中心】",       text: "您的ETC认证信息已失效，请点击 w.a1etc-renewed.com 重新完成认证，避免影响您的高速正常通行。" },
      { tag: "express-loss",     sender: "陌生号码 · 短信",      text: "您的快递在转运途中丢失，我们是XX快递理赔部。加微信 kdzf88 走全额理赔流程，赔偿金今天就能打给您。" },
      { tag: "points",           sender: "【积分兑换】",         text: "您的银行积分即将于明日清零！可兑换价值368元空气炸锅一台，请速戳链接兑换，逾期作废。" },
      { tag: "unsubscribe",      sender: "【XX会员】· 短信",     text: "您的会员服务今日到期将自动续费，每年扣费298元。如需取消请回复TD至该号码或点击 vip-qx123.com 取消。" },
      { tag: "account-recovery", sender: "【平台安全】",         text: "您于凌晨3点异地尝试登录异常，需点击 anquan-verify.cn 重新校验身份，否则24小时后冻结账号。" },
      { tag: "ghostwriting",     sender: "论文服务 · 微信",      text: "本机构承接本/硕/博毕业论文代写，包过查重，包修到答辩通过。需先付30%定金，定金800元起，签订保密协议。" },
      { tag: "stock-tip",        sender: "股友 · 微信(陌生)",    text: "本月带单胜率87%，跟上不同步加群。只收小圈5人，先收入场费688元，第一月收益不到30%全额退费。" },
      { tag: "charity",          sender: "爱心救助 · 朋友圈",    text: "求助！我儿子5岁确诊白血病，已花光积蓄。点击 ai-xin.com/leukemia 捐款，您的善款将直接打到我私人账户。" },
      { tag: "flight-refund",    sender: "【XX航空客服】· 短信",  text: "您预订的9.30 XH2310航班因机械故障取消，请联系客服400-XXX-XXXX办理改签/退票，需先缴纳改签手续费180元。" },
      { tag: "insurance-surrender", sender: "退保代理 · 电话",  text: "您购买的XX保险可全额退保，我们走“内部渠道”快办。需先付600元操作费，到账后退还。" },
      { tag: "product-recall",      sender: "售后召回 · 短信",  text: "您购买的XX吸尘器因配件问题被召回，请联系客服办理退一赔三。需先支付50元快递保证金到指定账户。" },
      { tag: "lucky-draw",           sender: "【XX品牌周年庆】",  text: "恭喜您在周年庆被抽中二等奖iPhone！需先缴588元个人所得税至指定账户，确认后48小时内送货上门。" },
      { tag: "franchise",            sender: "招商加盟 · 微信",  text: "我司诚招城市代理，月入8万。先转9800元加盟定金，含首批货品+培训，30天回本，慢的全额退。" },
      { tag: "auction-proxy",        sender: "拍卖代理 · 短信",  text: "拍卖会25日开拍。注册代理权需先转2000元保证金，中标后转为拍卖款，未中标5个工作日退还。" }
    ],
    // 伪装得很好的骗局（x ≤ -0.5，低可疑）
    low: [
      { tag: "boss",             sender: "李总 · 微信(新号码)",   text: "小张，我是李总，我手机坏了换了个号。你现在方便吗？马上转5万到这个账户：6222xxxx，对方等着收款签合同，回头财务给你报销。" },
      { tag: "secondhand",       sender: "二手交易 · 平台私聊",   text: "出一台95新手机，比市场价便宜800。平台流程太麻烦，你先拍下“保证金”链接交300元押金，我再发真机给你。" },
      { tag: "stock-tip-low",    sender: "网友 · 聊天记录",      text: "我跟的这个导师单子今天又+15%了，截图发你。你先小金额跟一手试试水，赚了再加大，我带你。" },
      { tag: "teacher",          sender: "陌生号码 · 短信",      text: "家长您好，我是孩子的班主任，学校要统一订购下学期教辅资料，麻烦加我私人微信转账给教务处代收。" },
      { tag: "friend-loan",      sender: "老王 · QQ(新号码)",    text: "哥们，我车被追尾修车钱不够，你先借我5000，下个月还你。这事别跟我老婆说，时间紧打我新卡号就行。" },
      { tag: "crowdfunding",     sender: "同学 · 微信",         text: "帮我转发下，我表姐确诊重病，水滴筹链接发你。要是你方便捐点，直接转我微信我帮你一起凑齐。" },
      { tag: "colleague",        sender: "财务小陈 · 微信",     text: "李哥，公司团建餐费先垫付了350元，报销走流程慢，方便的话直接转我，下周对接午饭时一起报销给你。" },
      { tag: "course-refund",    sender: "【XX网课】· 客服",     text: "您去年购买的英语课程因机构调整可退费1280元。退款需先核验身份，加理赔QQ6601xx，请提供支付宝账号便于核验。" },
      { tag: "matchmaker",      sender: "婚介顾问 · 微信",     text: "您上次见的男士对您印象很好，想约下次见面。咱们服务需续费6800元升级套餐，先转3000诚意金，余款会员期内付清。" },
      { tag: "model-audition",   sender: "星探 · 微信",         text: "看您朋友圈照片气质很好，有个广告试镜合适您，酬劳5000/天。需先交800元形象档案建档费，过审后返还。" },
      { tag: "company-change",  sender: "张经理 · 微信(新号)", text: "小王，公司座机坏了换号。下午要去见重要客户，先汇5000元给他做见面礼，回公司走流程给你报。" },
      { tag: "internet-friend", sender: "网友 · 微信",        text: "宝，我国外读书家里断供了，下月机票回国就来见你。先转我5000救急可以吗？回国后还你双倍。" },
      { tag: "mutual-aid",      sender: "投资群 · QQ",       text: "群内互助金前期名额制，先交200元会员费，下月开张入金即返300%收益。我已交，截图发你看。" },
      { tag: "wrong-transfer",  sender: "陌生号码 · 短信",     text: "我客户误转您账户5000元，请退回。为表谢意给您100元话费。请直接转账至这个账户，谢谢。" },
      { tag: "groupBuy",        sender: "社区团购群 · 微信",  text: "肉品刚到货，您定的那批1000元余款请直接转我，群里登记慢，今晚不留货，明天统一配送。" }
    ]
  },
  noise: {
    // 看起来很像骗局、但其实是真的（x > +0.5 时出现）
    high: [
      { tag: "bank-anomaly",     sender: "【XX银行】(95533)",    text: "尊敬的客户：您的账户今日14:32发生一笔异常消费（¥4,980.00）。如非本人操作，请立即致电官方客服95533核实挂失。" },
      { tag: "school-fee",      sender: "【学校教务处】",       text: "各位同学：本学期学费缴纳通道已开启，请于本周五前登录学校官方缴费平台完成缴费，逾期将影响下学期选课。" },
      { tag: "train-ticket",    sender: "【12306铁路客服】",    text: "您预订的9月30日G1371次列车已出票。如行程有变，请提前在官方渠道办理退票或改签，避免产生损失。" },
      { tag: "medical-insurance", sender: "【医保局】",          text: "您的医保账户存在异常报销记录，请携带身份证与就诊单据，于本周内前往参保地医保经办机构现场核验。" },
      { tag: "social-security",  sender: "【社保中心】",         text: "您近3个月社保存在断缴记录，影响购房资格与医保报销。请尽快登录社保网上服务大厅核实补缴。" },
      { tag: "credit-overdue",   sender: "【XX银行信用卡】",     text: "提醒：您的信用卡本期账单已逾期3天，将上报征信系统。请尽快通过官方APP还款，避免影响个人信用。" },
      { tag: "anti-fraud-notice", sender: "【国家反诈中心】",     text: "您近期接到过疑似诈骗电话，请提高警惕。陌生人的“安全账户”不存在，要求转账的均属诈骗。本短信不索取任何信息。" },
      { tag: "bank-freeze",      sender: "【XX银行】(95588)",    text: "您的账户因触发风控规则被临时限制非柜面交易。请携带身份证至附近网点核验身份解除限制，详情致电95588。" },
      { tag: "mortgage-rate",    sender: "【XX银行个贷中心】",   text: "您所在城市的首套房贷利率政策已调整，您当前贷款利率可申请下调0.35%。请通过个贷经理预约线下办理，免费咨询。" },
      { tag: "fraud-propaganda", sender: "社区派出所 · 短信",   text: "本周我所接到3起冒充快递理赔类诈骗报警，请居民勿轻信任何加QQ转账办理理赔的消息，有问题直接拨打110核实。" },
      { tag: "medical-emergency",  sender: "【XX市第一医院】",     text: "您的家人XXX在我院急诊就诊，情况稳定但需家属签字。请速至急诊楼3层护士站，路上可致电科主任6228XXXX了解。免打款。" },
      { tag: "credit-repair",      sender: "【XX银行征信中心】",   text: "您的征信异议申请已受理，调查期15个工作日。请勿轻信任何承诺“征信修复”的中介，本服务全程免费。" },
      { tag: "tax-deadline",        sender: "【XX税务局】",         text: "您本月增值税申报截止9月30日，请于截止日前完成申报，逾期将影响纳税信用等级。可登录电子税务局自助办理。" },
      { tag: "health-notice",       sender: "【市卫健委】",         text: "您的疫苗接种记录存在缺漏，请于10月底前至就近接种点补种，避免影响出行及入学登记。本短信不索取任何费用。" },
      { tag: "consumer-complaint",  sender: "【12315平台】",       text: "您投诉的“XX商家不退款”已立案调查，结果将于15个工作日内反馈。请勿通过本短信回复任何个人信息。" }
    ],
    // 有点可疑但真实（-0.5 < x ≤ +0.5）
    medium: [
      { tag: "real-estate",      sender: "置业顾问小刘",         text: "王先生您好，我是昨天带您看房的小刘。今天那套三居室来了个客户意向很强，您考虑得怎么样？要不等下周价格就不好说了。" },
      { tag: "express-delivery", sender: "【顺丰速运】",         text: "您的快递因地址信息不详暂时滞留网点，请致电派送员138****2951核实地址，我们将安排二次派送。" },
      { tag: "community",        sender: "社区网格员",          text: "您好，我是咱们社区的网格员。明天上午9点统一上门做消防安全隐患排查，麻烦家里留个人配合一下，谢谢。" },
      { tag: "utilities",        sender: "房东张阿姨",          text: "小王，这个月水电燃气费一共326块，比上个月多了点，夏天空调费上来了。你方便的话这两天转我就行。" },
      { tag: "car-maintenance",  sender: "【XX 4S店】",         text: "您的爱车保养里程已到，本次保养含机油机滤约780元。如需预约可回复1，我们将为您安排最近时段。" },
      { tag: "access-control",   sender: "【物业服务中心】",     text: "本小区门禁卡系统将于本周五升级，旧卡需到物业处免费换新。请凭房号或租赁合同在工作日9:00-17:30前来办理。" },
      { tag: "credit-limit",     sender: "【XX银行信用卡】",     text: '您符合临时提额条件，可申请将额度调至50,000元，临时额度有效期30天，到期自动恢复。回复"Y"申请，"N"忽略。' },
      { tag: "hr-tax",           sender: "公司HR · 企业微信",    text: "各位同事：本月专项附加扣除信息有变更的请在个人所得税APP里提交，HR不再代收资料。截止本周五，逾期影响本月扣税。" },
      { tag: "parking",          sender: "邻居802 · 微信",      text: "您好，我是802的，您这周常停在我车位上，我家这周来客人要用，能否这两天换到806空位？拜托了，谢谢。" },
      { tag: "court-notice",     sender: "【XX区人民法院】",     text: "您被列为(2026)X民初1234号案件被告，请于10月15日14:00到本院第3审判庭应诉。传票已通过EMS寄出，详情可拨打12368查询。" },
      { tag: "medical-appointment",  sender: "【XX体检中心】",   text: "您的体检预约已成功，时间为本周五上午9点。请注意空腹、带身份证。如需改期可致电预约台。" },
      { tag: "vehicle-inspection",   sender: "【车管所】",       text: "您的车辆将于本月到期年检，请提前一周通过交管12123预约地点，需带交强险保单与行驶证。所有手续均无费用。" },
      { tag: "insurance-premium",     sender: "【XX人寿保险】",   text: "您的XX保险本期保费3,860元将于9月30日自动扣款，请确保账户余额充足。如需变更缴费方式请联系您的客户经理。" },
      { tag: "broadband-renewal",      sender: "【XX宽带】",        text: "您的家庭宽带合约即将到期，可登录运营商APP续约。续约办理免费送6个月提速包，老用户续约无需代理。" },
      { tag: "neighborhood-committee", sender: "居委 · 短信",      text: "本周日上午9点居委在小广场开展免费血压测量和健康咨询活动，欢迎居民参加。请勿提前到访付款预约，纯公益。" }
    ],
    // 普通日常消息（x ≤ -0.5）
    low: [
      { tag: "weather",          sender: "天气预报 · 短信",      text: "明天白天多云转小雨，气温22℃-27℃，东北风3级。外出请携带雨具，注意添衣。" },
      { tag: "water-tank",       sender: "【物业服务中心】",     text: "本周六上午8:00-11:00将对二次供水水箱进行清洗消毒，期间短时停水，请您提前做好储水准备。" },
      { tag: "dinner",           sender: "老同学 · 微信",       text: "晚上一起吃饭吗？老地方，六点半。人多热闹一点，把那几个没见的也叫上。" },
      { tag: "library",          sender: "【图书馆】",          text: "您借阅的《心理学与生活》将于3天后到期，如需续借可在官方小程序一键办理。" },
      { tag: "phone-bill",       sender: "【中国移动】",        text: "您的话费充值50元已到账，当前余额62.40元。如需查询详单可登录中国移动APP。" },
      { tag: "member-points",    sender: "【XX超市会员】",       text: "您的会员积分本月末过期188分，可到店兑换纸巾或洗衣液等日用品，过期不补。" },
      { tag: "gym",              sender: "【XX健身】",          text: "提醒：您的私教课剩余3次，本周末到期，请尽快预约。如需延期可联系前台，可申请一次免费延期7天。" },
      { tag: "secondhand-done",  sender: "【闲鱼】",            text: "您的订单“九成新 Kindle”已完成，请确认收货。如对商品满意可点击评价，遇到纠纷请通过平台维权。" },
      { tag: "driving-test",     sender: "【车管所】",          text: "您的科目三考试已通过，可于下周通过交管12123APP预约科目四。理论考试地点已短信通知，请按时到场。" },
      { tag: "deposit-arrival",  sender: "【XX银行】",          text: "您账户于09-27 09:15收到转入款项￥3,500.00，对方账户：王某某(尾号8621)，余额￥12,480.50。" },
      { tag: "sports",            sender: "球友老赵 · 微信",    text: "周末打球吗？周日10点老地方，叫上老李他们，2小时场地我已经订好了，球场见。" },
      { tag: "movie",             sender: "【猫眼电影】",      text: "您购买的电影票已开票，检票前请凭取票码至自助机取票。如需退改请提前30分钟操作。" },
      { tag: "parking-fee",        sender: "【XX智慧停车】",     text: "您的车今日停车8小时，应缴32元。可扫码离场缴费或自助机付款，无需现金、无需APP。" },
      { tag: "exam-registration",  sender: "【考试报名系统】",   text: '您报名的"心理咨询师基础培训"考试已成功，考试时间为11月15日，准考证考前一周开放下载。' },
      { tag: "hotpot",             sender: "【XX火锅店】微信",   text: "明天7点半已经给您留好2人桌啦，到时候打电话说一声，迟到我们最多保留15分钟。" }
    ]
  }
};

/**
 * 去重配置。
 * 策略：以"本局内已用过的文案"为强约束（一局 20 题，每档最多 ~10 条左右，
 * 每档 10 条池子足够），同时再用 TAG_AVOID 个主题作软约束避免"同主题连续刷屏"。
 * 极端参数（如 P(S)=0.8 + d′=3，某档试验数 > 10）下回退到 tag 去重，仍能
 * 保证不会连续重复相同主题。
 */
const TAG_AVOID = 3;

/** 内部证据 x → 消息可疑等级的映射阈值 */
const LEVEL_THRESHOLDS = { high: 0.5, medium: -0.5 };  // x>0.5→high；-0.5<x≤0.5→medium；否则 low

/** d′ 难度档位说明文字 */
const DPRIME_LABELS = dp =>
  dp >= 2 ? "简单（骗局特征明显）" : dp >= 1 ? "中等（需要动脑）" : "困难（真假难辨）";

/* ---------------- DOM 引用 ---------------- */

const $ = id => document.getElementById(id);
const screens = { intro: $("screen-intro"), game: $("screen-game"), result: $("screen-result") };

/* ---------------- 全局状态 ---------------- */

const state = {
  pSignal: 0.5,       // 先验概率 P(S)
  dprime: 1.2,        // 本局设定的敏感度
  trials: [],         // 本局的试验队列（预先生成）
  index: 0,           // 当前试验序号
  responses: [],      // 每次试验的记录 {isSignal, saidFraud}
  timerStart: 0,      // 当前试验开始时刻
  timerRAF: null,     // 倒计时动画句柄
  answering: false,   // 是否允许作答（防连点）
  // 强约束：本局内已经用过的所有文案引用（一局 20 题、每档 10 条池，
  // 默认参数下可保证整局零重复）
  usedInBlock: new Set(),
  // 软约束：每档最近用过的主题（tag），避免同主题连续刷屏
  lastPick: {
    fraud:  { high: { tags: [] }, medium: { tags: [] }, low: { tags: [] } },
    noise:  { high: { tags: [] }, medium: { tags: [] }, low: { tags: [] } }
  }
};

/* ---------------- 屏幕切换 ---------------- */

function showScreen(name) {
  Object.entries(screens).forEach(([key, el]) => el.classList.toggle("hidden", key !== name));
}

/* ============================================================
 * 屏幕 1：参数设置
 * ============================================================ */

$("p-signal").addEventListener("input", e => {
  state.pSignal = parseFloat(e.target.value);
  $("p-signal-value").textContent = state.pSignal.toFixed(2);
});

$("dprime-range").addEventListener("input", e => {
  state.dprime = parseFloat(e.target.value);
  $("dprime-value").textContent = state.dprime.toFixed(1) + "（" + DPRIME_LABELS(state.dprime) + "）";
  drawDistributions($("preview-chart"), state.dprime, null);
});

$("btn-start").addEventListener("click", startBlock);
$("btn-restart").addEventListener("click", () => startBlock());
$("btn-back").addEventListener("click", () => showScreen("intro"));

/* ============================================================
 * 试验生成
 * ============================================================ */

/**
 * 生成一次试验：
 * 1. 按先验概率决定真实身份（伯努利抽样）
 * 2. 抽样内部证据 x：噪音 N(0,1)，信号 N(d′,1)
 * 3. 按 x 选择对应可疑等级的文案
 */
function makeTrial() {
  const isSignal = Math.random() < state.pSignal;
  const evidence = gaussianRandom() + (isSignal ? state.dprime : 0);
  const level =
    evidence > LEVEL_THRESHOLDS.high ? "high" :
    evidence > LEVEL_THRESHOLDS.medium ? "medium" : "low";

  const pool = (isSignal ? MESSAGE_POOL.fraud : MESSAGE_POOL.noise)[level];
  const hist = state.lastPick[isSignal ? "fraud" : "noise"][level];

  // 第一优先：本局没用过 + 主题不在最近 TAG_AVOID 个里
  let candidates = pool.filter(m => !state.usedInBlock.has(m) && !hist.tags.includes(m.tag));
  // 第二优先：本局没用过（放宽主题约束，但保证局内不重）
  if (candidates.length === 0) candidates = pool.filter(m => !state.usedInBlock.has(m));
  // 第三优先：本局用过的也行，但避开最近用过的主题（极端参数下回退路径）
  if (candidates.length === 0) candidates = pool.filter(m => !hist.tags.includes(m.tag));
  // 兜底（理论几乎不触发）
  if (candidates.length === 0) candidates = pool;

  const msg = candidates[Math.floor(Math.random() * candidates.length)];
  state.usedInBlock.add(msg);

  // 更新主题去重历史
  hist.tags.push(msg.tag);
  if (hist.tags.length > TAG_AVOID) hist.tags.shift();

  return { isSignal, level, msg };
}

/** 预生成一整局（20 条）试验 */
function buildBlock() {
  state.trials = [];
  state.usedInBlock = new Set();   // 重置本局去重集合
  state.lastPick = {
    fraud:  { high: { tags: [] }, medium: { tags: [] }, low: { tags: [] } },
    noise:  { high: { tags: [] }, medium: { tags: [] }, low: { tags: [] } }
  };
  for (let i = 0; i < TRIALS_PER_BLOCK; i++) state.trials.push(makeTrial());
}

/* ============================================================
 * 屏幕 2：游戏流程
 * ============================================================ */

function startBlock() {
  buildBlock();
  state.index = 0;
  state.responses = [];
  $("trial-total").textContent = TRIALS_PER_BLOCK;
  showScreen("game");
  nextTrial();
}

function nextTrial() {
  if (state.index >= state.trials.length) {   // 本局结束 → 出报告
    showResults();
    return;
  }
  const trial = state.trials[state.index];
  $("trial-index").textContent = state.index + 1;
  $("caught-count").textContent = state.responses.filter(r => r.isSignal && r.saidFraud).length;
  $("msg-sender").textContent = trial.msg.sender;
  $("msg-text").textContent = trial.msg.text;

  state.answering = true;
  state.timerStart = performance.now();
  tickTimer();
}

/** 倒计时进度条（requestAnimationFrame 平滑更新） */
function tickTimer() {
  const elapsed = performance.now() - state.timerStart;
  const remain = Math.max(0, 1 - elapsed / TIME_LIMIT_MS);
  const bar = $("timer-bar");
  bar.style.width = (remain * 100) + "%";
  if (elapsed >= TIME_LIMIT_MS) {
    recordAnswer(false, true);   // 超时 → 按“判为正常消息”计
    return;
  }
  state.timerRAF = requestAnimationFrame(tickTimer);
}

/**
 * 记录一次判断。
 * @param {boolean} saidFraud 是否判为“骗局”
 * @param {boolean} isTimeout 是否因超时自动判为“正常”
 */
function recordAnswer(saidFraud, isTimeout = false) {
  if (!state.answering) return;
  state.answering = false;
  cancelAnimationFrame(state.timerRAF);

  const trial = state.trials[state.index];
  state.responses.push({ isSignal: trial.isSignal, saidFraud });

  // 简短对错反馈（判断是否与真实身份一致）
  const correct = (saidFraud === trial.isSignal);
  const flash = $("feedback-flash");
  flash.textContent = isTimeout ? "⏰ 超时！按“正常消息”计"
                    : correct ? (trial.isSignal ? "✓ 识破骗局！" : "✓ 正确放行")
                              : (trial.isSignal ? "✗ 放走了骗局…" : "✗ 误伤正常消息…");
  flash.classList.add("show", correct ? "correct" : "wrong");

  setTimeout(() => {
    flash.classList.remove("show", "correct", "wrong");
    state.index++;
    nextTrial();
  }, FEEDBACK_MS);
}

$("btn-fraud").addEventListener("click", () => recordAnswer(true));
$("btn-normal").addEventListener("click", () => recordAnswer(false));

// 键盘快捷键：F = 骗局，J = 正常
document.addEventListener("keydown", e => {
  if (screens.game.classList.contains("hidden")) return;
  const k = e.key.toLowerCase();
  if (k === "f") recordAnswer(true);
  else if (k === "j") recordAnswer(false);
});

/* ============================================================
 * 屏幕 3：结果计算与展示（SDT 报告）
 * ============================================================ */

function showResults() {
  // 统计四格计数
  let hit = 0, miss = 0, fa = 0, cr = 0;
  state.responses.forEach(r => {
    if (r.isSignal && r.saidFraud) hit++;
    else if (r.isSignal && !r.saidFraud) miss++;
    else if (!r.isSignal && r.saidFraud) fa++;
    else cr++;
  });

  // 计算 SDT 指标（sdt.js）
  const sdt = computeSDT(hit, miss, fa, cr);

  // 填入四格表
  $("count-hit").textContent = hit;
  $("count-miss").textContent = miss;
  $("count-fa").textContent = fa;
  $("count-cr").textContent = cr;

  // 填入指标卡片
  $("m-phit").textContent = (sdt.pHit * 100).toFixed(1) + "%";
  $("m-pfa").textContent = (sdt.pFA * 100).toFixed(1) + "%";
  $("m-acc").textContent = (sdt.accuracy * 100).toFixed(1) + "%";
  $("m-dprime").textContent = sdt.dprime.toFixed(2);
  $("m-c").textContent = sdt.c.toFixed(2);

  // d′ 与 c 的通俗解读
  $("dprime-interpret").textContent =
    `解读：你的敏感性 d′ = ${sdt.dprime.toFixed(2)}（${sdt.dprime >= 2 ? "鉴别力很强" : sdt.dprime >= 1 ? "鉴别力中等" : "鉴别力偏弱，真假较难区分"}）；` +
    `判断标准 c = ${sdt.c.toFixed(2)}（${sdt.c > 0.15 ? "偏保守：更倾向判“正常”，容易漏掉骗局" : sdt.c < -0.15 ? "偏宽松：更倾向喊“骗局”，容易误伤正常消息" : "比较中立"}）。`;

  // 加分项图表 1：分布图（用本局设定的 d′，判断标准线 = −c）
  drawDistributions($("result-dist-chart"), state.dprime, -sdt.c);

  // 加分项图表 2：ROC 曲线（红点 = 你的实际 P(FA), P(Hit)）
  drawROC($("roc-chart"), { pHit: sdt.pHit, pFA: sdt.pFA });

  showScreen("result");
}

/* ---------------- 初始化：预览分布图 ---------------- */

drawDistributions($("preview-chart"), state.dprime, null);
